public class Main{
	public static void main(String args[]){
		CS objCS = new CS("CSE",5000);
		EEE objEEE = new EEE("EEE",5500);
		BBA objBBA = new BBA("BBA",4500);
		
		Student objStudent = new Student("Raiayan","15-28958-1");
		objStudent.setDepartment(objCS);
		objStudent.semesterFee(148);
		objStudent. showStudentInfo();
	}
}
abstract class Department{
	private String deptName;
	private int creditFee;

	Department(){
		this(" ",0);
	}
	Department(String deptName,int creditFee){
		this.deptName = deptName;
		this.creditFee = creditFee;
	
	}
	abstract void calculateSemesterFee(int credit);
	String getDeptName(){
		return deptName;
	}
	int getCreditFee(){
		return creditFee;
	}
	void setDeptName(String deptName){
		this.deptName = deptName;
	}
	void setCreditFee(int creditFee){
		this.creditFee = creditFee;
	}
	
	
}
class CS extends Department{
	CS(){
		this(" ",0);				
	}
	CS(String deptName,int creditFee){
		super(deptName,creditFee);
	}
	void calculateSemesterFee(int credit){
		System.out.println("Semester fee: " +(credit*this.getCreditFee()));
		
	}
	
}
class BBA extends Department{
	BBA(){
		this(" ",0);
	}
	BBA(String deptName,int creditFee){
		super(deptName,creditFee);
	}
	void calculateSemesterFee(int credit){
		System.out.println("Semester fee: " +(credit*this.getCreditFee()));
		
	}
	
}
class EEE extends Department{
	EEE(){
		this(" ",0);
	}
	EEE(String deptName,int creditFee){
		super(deptName,creditFee);
	}
	void calculateSemesterFee(int credit){
		System.out.println("Semester fee: " +(credit*this.getCreditFee()));
		
	}
	
}
class Student{
	private String stuName;
	private String stuID;
	private Department dept;
	Student(){
		
	}
	Student(String stuName,String stuID){
		this.stuName = stuName;
		this.stuID = stuID;
       
	}
	void showStudentInfo(){
		System.out.println("Student Name: "+this.stuName);
		System.out.println("Student ID: "+ this.stuID);
		System.out.println("Department Name: "+this.dept.getDeptName());
		
	}
	void setDepartment(Department dept){
		this.dept = dept;
	}
	void changeDepartment(Department dept){
		this.dept = dept;
		
	}
	void semesterFee(int totalCredit){
		dept.calculateSemesterFee(totalCredit);
	}
}