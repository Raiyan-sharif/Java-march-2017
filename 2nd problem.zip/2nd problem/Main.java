public class Main{
	public static void main(String args[]){
		BasicCalculator add = new BasicCalculator();
		add.sum(1,2);
		
	}
}
interface BasicCalculatorInterface{
	int sum(int x,int y);
	int sub(int x,int y);
	int multiplication(int x,int y);
	int division(int x,int y);
	}
interface ScientificCalculatorInterface{
	int XtoY(int x,int y);
}
class BasicCalculator implements BasicCalculatorInterface{
	public int sum(int x,int y){
		return (x+y);
	}
	public int sub(int x,int y){
		return (x-y);
	}
	public int multiplication(int x,int y){
	         return (x*y);
	}
	public int division(int x,int y){
		if(y>0){
			return x/y;
			}
		else{
			return 0;
			}
		}
	}
class ScientificCalculator extends BasicCalculator implements ScientificCalculatorInterface{
	public int XtoY(int x,int y){
		for(int i=1;i<=y;i++){
			x= x*y;
		}
		return x;
		}
}


